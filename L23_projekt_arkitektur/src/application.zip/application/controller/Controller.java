package application.controller;

import application.model.*;
import storage.Storage;

import java.time.LocalDate;
import java.util.ArrayList;

public class Controller {

    public static Forestilling createForestilling(String navn, LocalDate startDato, LocalDate slutDato) {
        Forestilling forestilling = new Forestilling(navn, startDato, slutDato);
        Storage.addForstilling(forestilling);
        return forestilling;
    }

    public static void deleteForestilling(Forestilling forestilling) {
        Storage.removeForstilling(forestilling);
    }

    public static void updateForestilling(Forestilling forestilling, String navn, LocalDate startDato, LocalDate slutDato) {
        forestilling.setNavn(navn);
        forestilling.setStartDato(startDato);
        forestilling.setSlutDato(slutDato);
    }

    public static ArrayList<Forestilling> getForstillinger() {
        return Storage.getForestillinger();
    }

    // -------------------------------------------------------------------------

    public static Kunde createKunde(String navn, String mobil) {
        Kunde kunde = new Kunde(navn, mobil);
        Storage.addKunder(kunde);
        return kunde;
    }

    public static void deleteKunde(Kunde kunde) {
        Storage.removeKunde(kunde);
    }

    public static void updateKunde(Kunde kunde, String navn, String mobil) {
        kunde.setNavn(navn);
        kunde.setMobil(mobil);
    }

    public static ArrayList<Kunde> getKunder() {
        return Storage.getKunder();
    }


    // -------------------------------------------------------------------------

    public static Plads createPlads(int række, int nr, int pris, PladsType pladsType) {
        Plads plads = new Plads(række, nr, pris, pladsType);
        Storage.addPlads(plads);
        return plads;
    }

    public static void deletePlads(Plads plads) {
        Storage.removePlads(plads);
    }

    public static void updatePlads(Plads plads, int række, int nr, int pris, PladsType pladsType) {
        plads.setRække(række);
        plads.setNr(nr);
        plads.setPris(pris);
        plads.setPladsType(pladsType);

    }

    public static ArrayList<Plads> getPlads() {
        return Storage.getPladser();
    }

    // -------------------------------------------------------------------------

    public static Bestilling opretBestillingMedPladser(Forestilling forestilling, Kunde kunde, LocalDate dato, ArrayList<Plads> pladser) {
        int optagedePladser = 0;
        for (int i = 0; i < pladser.size(); i++) {
            if (forestilling.erPladsLedig(pladser.get(i).getRække(), pladser.get(i).getNr(), dato)) {
                optagedePladser++;
            }
        }
        if (optagedePladser == 0) {
            Bestilling bestilling = new Bestilling(dato, forestilling);
            for (int i = 0; i < pladser.size(); i++) {
                bestilling.addPlads(pladser.get(i));
            }
            bestilling.setKunder(kunde);
            return bestilling;


        } else {
            return null;
        }
    }
}
