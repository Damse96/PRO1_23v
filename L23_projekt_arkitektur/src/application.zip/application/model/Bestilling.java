package application.model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Bestilling {
    private LocalDate dato;

    private Forestilling forestilling;
    private final ArrayList<Plads> pladser = new ArrayList<>();

    private Kunde kunder;

    public Bestilling(LocalDate dato, Forestilling forestilling) {
        this.dato = dato;
        this.forestilling = forestilling;
    }


    public LocalDate getDato() {
        return dato;
    }

    public void setDato(LocalDate dato) {
        this.dato = dato;
    }

    public ArrayList<Plads> getPladser() {
        return pladser;
    }

    public void addPlads(Plads plads){
        if (!pladser.contains(plads)){
            pladser.add(plads);
        }
    }

    public void removePlads(Plads plads){
        if (!pladser.contains(plads)){
            pladser.remove(plads);
        }
    }

    public Forestilling getForestilling() {
        return forestilling;
    }

    public void setKunder(Kunde kunde) {
        if (this.kunder != kunde) {
            Kunde oldKunder = this.kunder;
            if (oldKunder != null) {
                oldKunder.removBestillinger(this);
            }
            this.kunder = kunde;
            if (kunder != null) {
                kunder.addBestillinger(this);
            }
        }

    }
}
