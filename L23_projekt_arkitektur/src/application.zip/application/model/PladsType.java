package application.model;

public enum PladsType {
    Standard,EkstraBen, Kørestol
}
