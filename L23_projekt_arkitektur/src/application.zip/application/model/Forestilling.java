package application.model;

import java.time.LocalDate;
import java.util.ArrayList;

public class Forestilling {
    private String navn;
    private LocalDate startDato;

    private LocalDate slutDato;

    private final ArrayList<Bestilling> bestillinger = new ArrayList<>();

    public Forestilling(String navn, LocalDate startDato, LocalDate slutDato) {
        this.navn = navn;
        this.startDato = startDato;
        this.slutDato = slutDato;
    }

    public String getNavn() {
        return navn;
    }

    public void setNavn(String navn) {
        this.navn = navn;
    }

    public LocalDate getStartDato() {
        return startDato;
    }

    public void setStartDato(LocalDate startDato) {
        this.startDato = startDato;
    }

    public LocalDate getSlutDato() {
        return slutDato;
    }

    public void setSlutDato(LocalDate slutDato) {
        this.slutDato = slutDato;
    }

    public ArrayList<Bestilling> getBestilinger() {
        return bestillinger;
    }

    public Bestilling createBestilling(LocalDate dato){
        Bestilling bestilling = new Bestilling(dato, this);
        bestillinger.add(bestilling);
        return bestilling;
    }

    public void removeBestilling(Bestilling bestilling){
        if (bestillinger.contains(bestilling)){
            bestillinger.remove(bestilling);
        }
    }

    @Override
    public String toString() {
        return navn + " (" + startDato + " til " + slutDato + ")";
    }

    public boolean erPladsLedig(int række, int nr, LocalDate dato){
        for (Bestilling bestilling : bestillinger){
            if (bestilling.getDato().equals(dato)){
                for (Plads plads : bestilling.getPladser()){
                    if (plads.getRække() == række && plads.getNr() == nr){
                        return false;
                    }
                }
            }
        }
        return true;
    }
}
